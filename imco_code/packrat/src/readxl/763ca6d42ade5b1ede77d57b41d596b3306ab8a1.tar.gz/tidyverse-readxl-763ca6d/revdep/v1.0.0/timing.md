# Check times

|   |package           |version | check_time|
|:--|:-----------------|:-------|----------:|
|13 |heemod            |0.9.0   |     1729.8|
|16 |Luminescence      |0.7.4   |      143.8|
|28 |rotl              |3.0.3   |      116.6|
|23 |Rcmdr             |2.3-2   |      107.8|
|25 |RcmdrPlugin.EZR   |1.35    |       87.5|
|7  |dpcR              |0.4     |       82.8|
|2  |chillR            |0.66    |       81.7|
|6  |DLMtool           |3.2.3   |       73.1|
|19 |popprxl           |0.1.3   |       72.5|
|20 |QuantTools        |0.5.4   |       66.1|
|15 |lessR             |3.6.0   |       64.1|
|24 |RcmdrMisc         |1.0-5   |       56.8|
|8  |elementR          |1.3.0   |       55.6|
|32 |tidyxl            |0.2.1   |         55|
|21 |rattle            |4.1.0   |       53.9|
|10 |ezec              |1.0.1   |       53.3|
|11 |GerminaR          |1.1     |       52.8|
|1  |BEACH             |1.1.2   |       52.1|
|33 |TR8               |0.9.16  |       49.3|
|18 |photobiologyInOut |0.4.13  |       47.3|
|26 |RDML              |0.9-5   |       47.2|
|4  |CONS              |0.1.1   |       41.7|
|29 |shinyHeatmaply    |0.1.0   |       40.6|
|27 |rio               |0.4.16  |       36.3|
|14 |joinXL            |1.0.1   |       33.5|
|17 |manifestoR        |1.2.3   |       29.4|
|31 |tidyverse         |1.1.1   |         27|
|9  |evaluator         |0.1.0   |       24.5|
|34 |unvotes           |0.1.0   |       22.3|
|5  |DCM               |0.1.1   |         21|
|12 |GetTDData         |1.2.5   |       18.6|
|3  |ckanr             |0.1.0   |       16.8|
|22 |raw               |0.1.4   |       13.4|
|30 |textreadr         |0.3.1   |       13.4|
|35 |xlutils3          |0.1.0   |       13.2|


